ADMIN AIR - Proyek Android awal

Isi:
- Aplikasi Android sederhana berbasis WebView.
- Pencatatan pelanggan dan meteran.
- Tarif dapat diubah.
- Tarif disimpan pada setiap catatan sehingga tagihan lama tidak berubah.
- Status lunas/belum lunas.
- Bagikan ringkasan tagihan melalui WhatsApp.
- Backup dan pulihkan data JSON.
- Data tersimpan lokal pada perangkat melalui localStorage WebView.

Cara membuat APK:
1. Pasang Android Studio di komputer.
2. Buka folder proyek ini melalui Android Studio.
3. Tunggu Gradle selesai melakukan sinkronisasi.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK hasil build akan berada di app/build/outputs/apk/debug/app-debug.apk.

PENTING:
- Ini adalah source project awal, bukan APK yang sudah dikompilasi.
- Sebelum dipakai untuk pencatatan resmi, uji aplikasi dan rutin gunakan Backup data.
- Hapus data aplikasi atau uninstall dapat menghapus data lokal jika belum dibackup.
- Versi ini menyimpan satu catatan per pelanggan per periode; pengelolaan riwayat lanjutan dapat dikembangkan.
